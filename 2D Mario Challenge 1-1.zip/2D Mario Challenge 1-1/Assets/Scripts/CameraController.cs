﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

    public GameObject player;

    private Vector3 offset;

    void Start()
    {
        offset = transform.position - player.transform.position;
    }

    void LateUpdate()
    {
        if (player.transform.position.x > (transform.position.y - 3))
        {
            transform.position = new Vector3((player.transform.position.x + offset.x), transform.position.y, transform.position.z);
        }
    }
}
