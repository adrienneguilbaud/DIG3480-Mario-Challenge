﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {

    public Camera cam;

    private Rigidbody2D rb2d;
    public float speed;
    public float jumpForce;
    public int count;
    public Text countText;

    private bool isOnGround;
    public Transform groundcheck;
    public float checkRadius;
    public LayerMask allGround;
    private bool facingRight = true;

    private float horizontalMove;

    public Animator animator;
    public AudioSource coinSound;
    public AudioSource jumpSound;
    public AudioSource winMusicS;
    public AudioClip winMusic;
    private bool canPlayWinMusic;
    public AudioSource deadMusic;
    private bool canPlayDeadMusic;

    public bool isDead;
    public bool levelWin;
    private float deadTimer = 0.0f;
    private float deadTime = 3.0f;

    private float winTimer = 0.0f;
    private float winTime = 6.0f;

    // Use this for initialization
    void Start () {
        rb2d = GetComponent<Rigidbody2D>();
        count = 0;
        SetCountText();

        canPlayWinMusic = true;
        canPlayDeadMusic = true;
        isDead = false;
        levelWin = false;
        animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        if (!isDead && !levelWin)
        {
            if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
            {
                animator.SetBool("isRunning", true);
                //animator.SetBool("jump", false);
            }
            else
            {
                animator.SetBool("isRunning", false);
                //animator.SetBool("jump", false);
            }
        }
        if (Input.GetKey("escape"))
            Application.Quit();
    }

    void FixedUpdate()
    {
        if (!isDead && !levelWin)
        {
            float moveHorizontal = Input.GetAxis("Horizontal");

            Vector2 movement = new Vector2(moveHorizontal, 0);

            rb2d.AddForce(movement * speed);

            isOnGround = Physics2D.OverlapCircle(groundcheck.position, checkRadius);

            if (facingRight == false && moveHorizontal > 0)
            {
                Flip();
            }
            else if (facingRight == true && moveHorizontal < 0)
            {
                Flip();
            }
        }
        else if (isDead)
        {
            cam.GetComponent<AudioSource>().Stop();
            if (canPlayDeadMusic)
            {
                deadMusic.Play();
                canPlayDeadMusic = false;
            }

            Die();
            deadTimer = deadTimer + Time.deltaTime;
            if (deadTimer >= deadTime)
            {
                SceneManager.LoadScene(0);
            }
        } else if ((levelWin) && (!isDead))
        {
            Debug.Log("level win music through mario");
            cam.GetComponent<AudioSource>().Stop();
            if (canPlayWinMusic)
            {
                canPlayWinMusic = false;
                winMusicS.Play();
            }
            winTimer = winTimer + Time.deltaTime;
            if (winTimer >= winTime)
            {
                SceneManager.LoadScene(0);
            }
        }
    }

    void Flip()
    {
        facingRight = !facingRight;
        Vector2 Scaler = transform.localScale;
        Scaler.x = Scaler.x * -1;
        transform.localScale = Scaler;
    }
    
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Pickups"))
        {
            coinSound.Play();
            other.gameObject.SetActive(false);
            count = count + 1;
            SetCountText();
        }  
    }
    
    void OnCollisionStay2D(Collision2D collision)
    {
        if (!isDead)
        {
            if (collision.collider.tag == "Ground" && isOnGround)
            {
                if (Input.GetKey(KeyCode.UpArrow))
                {
                    animator.SetBool("jump", true);
                    rb2d.velocity = rb2d.velocity + Vector2.up * jumpForce;
                    jumpSound.Play();
                }
                else
                {
                    animator.SetBool("jump", false);
                }
            }
            if (collision.collider.tag == "Flag")
            {
                Debug.Log("level won");
                levelWin = true;
            }
        }
    }

    public void SetCountText ()
    {
        countText.text = "x " + count.ToString();
    }

    void Die()
    {
        animator.SetBool("isDead", true);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawSphere(groundcheck.position, checkRadius);
    }
}
