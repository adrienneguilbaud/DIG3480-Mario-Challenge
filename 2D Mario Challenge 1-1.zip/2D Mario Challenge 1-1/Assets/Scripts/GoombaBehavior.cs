﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoombaBehavior : MonoBehaviour
{
    public GameObject player;
    public float speed;
    public Animator animator;

    public Transform leftCheck;
    public Transform rightCheck;

    public bool moveLeft = true;

    private float deathTimer = 0.0f;
    public float deathTime = 0.5f;
    public AudioSource stomped;

    public bool stompedSoundPlayed;

    // Use this for initialization
    void Start()
    {
        stompedSoundPlayed = false;
        player = FindObjectOfType<PlayerController>().gameObject;
    }

    // Update is called once per frame
    void Update()
    {

        //check for collision on sides
        if (moveLeft && !animator.GetBool("isDead"))
        {
            transform.position = transform.position + (Vector3.left * speed) * Time.deltaTime;
        }
        else if (!moveLeft && !animator.GetBool("isDead"))
        {
            transform.position = transform.position + (Vector3.right * speed) * Time.deltaTime;
        }

        //If the goomba's animator is set to squish, then the goomba should hold the squish
        //sprite for a certain time. The lines below will increase a timer only if the parameter
        //in the animator is true.
        if (animator.GetBool("isDead"))
        {
            if (!stompedSoundPlayed)
            {
                stompedSoundPlayed = true;
                stomped.Play();
            }
            deathTimer = deathTimer + Time.deltaTime;
        }

        //If the timer is higher than the set time, destroy the goomba.
        if (deathTimer >= deathTime)
        {
            Destroy(gameObject);
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        moveLeft = !moveLeft;

        if (collision.collider.tag == "Player" && (player.transform.position.y > transform.position.y))
        {
            animator.SetBool("isDead", true);
            Debug.Log("Goomba dead");
        } else if (collision.collider.tag == "Player" && (player.transform.position.y < transform.position.y))
        {
            //Kill mario
            player.GetComponent<PlayerController>().isDead = true;
        }
    }
}
