﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelWin : MonoBehaviour {

    public AudioSource winMusic;
    public GameObject player;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Player")
        {
            //Debug.Log("level win through flag");
            player.GetComponent<PlayerController>().levelWin = true;
        }
    }
}
