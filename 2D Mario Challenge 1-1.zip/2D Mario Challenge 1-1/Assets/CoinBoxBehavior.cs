﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinBoxBehavior : MonoBehaviour {

    public GameObject player;
    public AudioSource coinSound;

	// Use this for initialization
	void Start () {
	}
	

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Player")
        {
            coinSound.Play();
            player.GetComponent<PlayerController>().count = player.GetComponent<PlayerController>().count + 1;
            player.GetComponent<PlayerController>().SetCountText();
        }
    }
}
